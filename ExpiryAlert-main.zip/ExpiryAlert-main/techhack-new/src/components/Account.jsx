import React from 'react';

function Account() {
  return (
    <div>
      <h1>Account</h1>
      <p>Manage your account here.</p>
    </div>
  );
}

export default Account;
